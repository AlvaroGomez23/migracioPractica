<?php

namespace App\Http\Controllers;

abstract class Controller
{
    // No borrar este fichero, los demas controladores petan si no esta
}

<!-- ALVARO GOMEZ -->

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/estilsFinals.css')); ?>"> <!-- Estils css -->
    <title>Articles Totals</title>
</head>
<body>
<a href="#main-content" class="skip-link">Saltar al contingut principal</a>
<header>
    <div class="logo">Admin panel</div>
    <div>
    </div>
    <div>
        <form action="<?php echo e(route('gestioUsers')); ?>" method="GET" class="form">
            <input class="botons" type="submit" value="Gestió Usuaris">
        </form>
    </div>
    <div class="signin-form">
        <div class="dropdown">
            <button class="dropbtn">Compte</button>
            <div class="dropdown-content">
                <a href="<?php echo e(route('perfil')); ?>">Perfil</a>
                <a href="<?php echo e(route('infoApi')); ?>">Informació API</a>
                <a href="<?php echo e(route('logout')); ?>">Logout</a>
            </div>
        </div>
    </div>
</header>

<h1 class="notfound">ARTICLES</h1>

<div class="articlesTotals" id="main-content">
    <?php if($articles->isEmpty()): ?>
        <p class="notfound">No s'han trobat resultats</p>
    <?php else: ?>
        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="articles" tabindex="0">
                <h2 tabindex="0"><?php echo e($article->nom); ?></h2>
                <p tabindex="0"><?php echo e($article->descripcio); ?></p>
                <p tabindex="0">ID Autor: <?php echo e($article->id_usuari); ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>

<!-- Paginació -->
<?php if($articles->total() > 0): ?>
    <div class="paginacio">
        <?php echo e($articles->links('pagination::bootstrap-4')); ?>

    </div>
<?php endif; ?>

</body>
</html><?php /**PATH C:\laragon\www\migracioPractica\resources\views\admin.blade.php ENDPATH**/ ?>
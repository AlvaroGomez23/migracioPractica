<!-- filepath: c:\laragon\www\migracioPractica\resources\views\api\index.blade.php -->

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>API - Plantilles</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/estilsAPI.css')); ?>">
</head>
<body>
    <h1>Resultats de la API</h1>

    <form action="<?php echo e(route('api')); ?>" method="GET">
        <input type="text" name="nom" placeholder="Cerca per nom" value="<?php echo e($nom); ?>">
        <button type="submit">Cercar</button>
    </form>

    <table border="1">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nom</th>
                <th>Descripció</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $plantilles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plantilla): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($plantilla->id); ?></td>
                    <td><?php echo e($plantilla->nom); ?></td>
                    <td><?php echo e($plantilla->descripcio); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3">No s'han trobat resultats.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html><?php /**PATH C:\laragon\www\migracioPractica\resources\views\api.blade.php ENDPATH**/ ?>
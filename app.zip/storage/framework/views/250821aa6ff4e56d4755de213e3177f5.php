<!-- resources/views/auth/login.blade.php -->

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/estilsLS.css')); ?>">
    <title>Formulario de Login</title>
    <script src="https://www.google.com/recaptcha/api.js?render=6LfHsokqAAAAADoBhjjekIvi6UkOZpCqFvAjrEQ7"></script>
</head>
<body>
    <div class="login-container">
        <h2>Iniciar Sessió</h2>
        <form action="<?php echo e(route('auth.login')); ?>" method="POST" id="login-form">
            <?php echo csrf_field(); ?>
            <input type="email" name="email" class="input-field" placeholder="Email" value="<?php echo e(old('email')); ?>">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="error"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <input type="password" name="contrasenya" class="input-field" placeholder="Contrasenya">
            <?php $__errorArgs = ['contrasenya'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="error"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <label for="remember">Recorda'm <input type="checkbox" name="remember" id="remember"> </label>

            <button id="login-button" class="botons" 
                data-sitekey="reCAPTCHA_site_key" 
                data-callback='onSubmit' 
                data-action='submit'>Login</button>
        </form>

        <?php if($errors->has('oauth')): ?>
            <div class="error">
                <?php echo e($errors->first('oauth')); ?>

            </div>
        <?php endif; ?>

        <div>
            <a href="<?php echo e(route('auth.google.redirect')); ?>">
                <img class="icon" src="https://www.keyweo.com/wp-content/uploads/2022/03/el-logo-g-de-google.png" alt="Google Logo">
            </a>

            <a href="<?php echo e(route('github')); ?>">
                <img class="icon" src="<?php echo e(asset('fotos/icons/garrapinyades.png')); ?>" alt="GitHub Logo">
            </a>

            <a href="<?php echo e(route('auth.google.redirect')); ?>" class="btn btn-google">
                Inicia sessió amb Google
            </a>
        </div>

        <form action="<?php echo e(url('/')); ?>">
            <input type="submit" value="Tornar" class="botons">
        </form>
        <a href="<?php echo e(route('recuperarContrasenyaGet')); ?>" class="forgot-password">Contrasenya oblidada?</a>

        <div class="signup-link">
            No tens compte? <a href="<?php echo e(route('signin')); ?>">Enregistra't</a>
        </div>
    </div>

    <script>
        grecaptcha.ready(function() {
            document.getElementById('login-form').addEventListener('submit', function(event) {
                event.preventDefault();
                grecaptcha.execute('6LfHsokqAAAAADoBhjjekIvi6UkOZpCqFvAjrEQ7', {action: 'login'}).then(function(token) {
                    const recaptchaInput = document.createElement('input');
                    recaptchaInput.type = 'hidden';
                    recaptchaInput.name = 'g-recaptcha-response';
                    recaptchaInput.value = token;
                    document.getElementById('login-form').appendChild(recaptchaInput);
                    document.getElementById('login-form').submit();
                });
            });
        });
    </script>
</body>
</html>
<?php /**PATH C:\laragon\www\migracioPractica\resources\views\login.blade.php ENDPATH**/ ?>
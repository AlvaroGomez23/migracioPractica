<!-- filepath: c:\laragon\www\migracioPractica\resources\views\recuperarContrasenya.blade.php -->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/estilsForms.css')); ?>"> <!-- Estils css -->
    <title>Recuperar Contrasenya</title>
</head>
<body>
    <div class="container">
        <h2>Recuperar Contrasenya</h2>
        <form action="<?php echo e(route('recuperarContrasenya')); ?>" method="POST">
            <?php echo csrf_field(); ?> 
            <input type="email" name="email" class="input-field" placeholder="Email" required>
            <input type="submit" value="Recuperar Contrasenya" class="botons">
        </form>

        <?php if(session('success')): ?>
            <div class="success-message">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="error-messages">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('home')); ?>">
            <input type="submit" value="Tornar" class="botons">
        </form>
    </div>
</body>
</html><?php /**PATH C:\laragon\www\migracioPractica\resources\views\recuperarContrasenya.blade.php ENDPATH**/ ?>
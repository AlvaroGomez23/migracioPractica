<!-- resources/views/auth/signin.blade.php -->

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/estilsLS.css')); ?>">
    <title>Formulario de Sign In</title>
</head>
<body>
    <div class="signin-container">
        <h2>Registrar-Se</h2>
        
        <form method="POST" action="<?php echo e(route('auth.signin')); ?>">
            <?php echo csrf_field(); ?>
            <input type="text" aria-label="nom usuari" name="nom" class="input-field" placeholder="Nom d'usuari" value="<?php echo e(old('nom')); ?>" required>
            <?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="error"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <input type="email" aria-label="email" name="email" class="input-field" placeholder="Mail Ex. someone@fromsomewhere.com" value="<?php echo e(old('email')); ?>" required>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="error"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <input type="password" aria-label="contrasenya" name="contrasenya" class="input-field" placeholder="Contrasenya" required>
            <?php $__errorArgs = ['contrasenya'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="error"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <input type="password" aria-label="repetir contrasenya" name="contrasenya_confirmation" class="input-field" placeholder="Torna a introduir la contrasenya" required>
            <input type="submit" aria-label="sign in" value="Sign In" class="botons">
        </form>
        
        <?php if($errors->any()): ?>
            <div class="error-messages">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('home')); ?>">
            <input type="submit" value="Tornar" class="botons">
        </form>

        <div class="signup-link">
            Ja tens compte? <a href="<?php echo e(route('login')); ?>">Inicia la sessió aquí</a>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\laragon\www\migracioPractica\resources\views\signin.blade.php ENDPATH**/ ?>
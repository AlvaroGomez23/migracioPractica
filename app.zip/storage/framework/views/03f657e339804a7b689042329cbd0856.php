<div>
    <header>
        <div class="logo">Articles</div>
        <div class="contenidorBotons">
            <form action="<?php echo e(route('signin')); ?>">
                <input class="botons" type="submit" value="Sign In">
            </form>
            <form action="<?php echo e(route('login')); ?>">
                <input class="botons" type="submit" value="Log In">
            </form>
        </div>
    </header>
</div><?php /**PATH C:\laragon\www\migracioPractica\resources\views\components\navbar.blade.php ENDPATH**/ ?>
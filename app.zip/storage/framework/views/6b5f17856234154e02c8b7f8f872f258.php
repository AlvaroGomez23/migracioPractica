<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Articles Totals</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/estilsFinals.css')); ?>"> 
</head>
<body>
    <a href="#main-content" class="skip-link">Saltar al contingut principal</a>

    <header>
        <div class="logo">
            Hola! <?php echo e(Auth::user()->nom ?? 'Usuari'); ?>

        </div> 

        <div class="signin-form">
            <form action="<?php echo e(route('inserirArticle')); ?>">
                <input class="botons" type="submit" value="Inserir Article">
            </form>
        </div>

        <div class="signin-form">
            <div class="dropdown">
                <button class="dropbtn">Compte</button>
                <div class="dropdown-content" tabindex="0">
                    <a href="<?php echo e(route('perfil')); ?>">Perfil</a>
                    <a href="<?php echo e(route('infoApi')); ?>">Informació API</a>
                    <a href="<?php echo e(route('logout')); ?>">Logout</a>
                </div>
            </div>
        </div>
    </header>

    <div class="margin">
        <h1 class="notfound">Articles</h1>

        <form method="GET">
            <div class="selector">
                <label for="articlesPerPagina" class="labelArticles">Quantitat Articles (Per Pàgina):</label>
                <select class="botons" id="articlesPerPagina" name="articlesPerPagina" onchange="this.form.submit()">
                    <?php $__currentLoopData = [5, 10, 15, 20, 25, 30]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($option); ?>" <?php echo e(request('articlesPerPagina') == $option ? 'selected' : ''); ?>><?php echo e($option); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="selector">
                <label for="ordreArticles">Ordenar Articles</label>
                <select class="botons" name="ordreArticles" id="ordreArticles" onchange="this.form.submit()">
                    <option value="asc" <?php echo e(request('ordreArticles') == 'asc' ? 'selected' : ''); ?>>Ascendent (Nom)</option>
                    <option value="desc" <?php echo e(request('ordreArticles') == 'desc' ? 'selected' : ''); ?>>Descendent (Nom)</option>
                </select>
            </div>
        </form>

        <div class="articlesTotals" id="main-content">
            <?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="articles" tabindex="0">
                    <h2 tabindex="0"><?php echo e($article->nom); ?></h2>
                    <p tabindex="0"><?php echo e($article->descripcio); ?></p>

                   
                    <form action="<?php echo e(route('articles.edit', ['id' => $article->id])); ?>" method="GET" style="display: inline;">
                        <button type="submit" class="botons">Editar</button>
                    </form>

                    
                    <form action="<?php echo e(route('articles.delete', ['id' => $article->id])); ?>" method="POST" style="display: inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="botons" onclick="return confirm('Estàs segur que vols eliminar aquest article?')">Eliminar</button>
                    </form>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="notfound">No s'han trobat articles.</p>
            <?php endif; ?>
        </div>

        <!-- Paginación -->
        <div class="paginacio">
            <?php if($articles->currentPage() > 1): ?>
                <a href="<?php echo e($articles->previousPageUrl()); ?>"> < </a>
            <?php else: ?>
                <button disabled> < </button>
            <?php endif; ?>

            <?php $__currentLoopData = range(1, $articles->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e($articles->url($page)); ?>" class="<?php echo e($page == $articles->currentPage() ? 'active' : ''); ?>"><?php echo e($page); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if($articles->currentPage() < $articles->lastPage()): ?>
                <a href="<?php echo e($articles->nextPageUrl()); ?>"> > </a>
            <?php else: ?>
                <button disabled> > </button>
            <?php endif; ?>
        </div>

        <form action="<?php echo e(route('home')); ?>">
            <input class="botons" type="submit" value="Tornar">
        </form>
    </div>
</body>
</html><?php /**PATH C:\laragon\www\migracioPractica\resources\views\dashboard.blade.php ENDPATH**/ ?>
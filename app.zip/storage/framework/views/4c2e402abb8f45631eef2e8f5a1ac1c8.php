<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Articles Totals</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/estilsFinals.css')); ?>">
</head>
<body>
    <?php echo $__env->make('components.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <a href="#main-content" class="skip-link">Saltar al contingut principal</a>
    <div class="margin">
        <div class="search-bar">
            <form id="searchForm" method="GET">
                <input type="text" name="buscar" placeholder="Escriu el valor a cercar..." value="<?php echo e(request('buscar')); ?>">
                <button type="submit"><img class="icon" src="<?php echo e(asset('img/icons/lupa.png')); ?>" alt="boto buscar"></button>
            </form>
        </div>
        
        <div class="centrar">
            <form method="GET">
                <input type="hidden" name="buscar" value="<?php echo e(request('buscar')); ?>">
                <div class="selector">
                    <label for="articlesPerPagina">Quantitat Articles (Per Pàgina):</label>
                    <select class="botons" id="articlesPerPagina" name="articlesPerPagina" onchange="this.form.submit()">
                        <?php $__currentLoopData = [5, 10, 15, 20, 25, 30]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($option); ?>" <?php echo e(request('articlesPerPagina') == $option ? 'selected' : ''); ?>><?php echo e($option); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="selector">
                    <label for="ordreArticles">Ordenar Articles</label>
                    <select class="botons" name="ordreArticles" id="ordreArticles" onchange="this.form.submit()">
                        <option value="asc" <?php echo e(request('ordreArticles') == 'asc' ? 'selected' : ''); ?>>Ascendent (Nom)</option>
                        <option value="desc" <?php echo e(request('ordreArticles') == 'desc' ? 'selected' : ''); ?>>Descendent (Nom)</option>
                    </select>
                </div>
            </form>
        </div>
        
        <div class="articlesTotals" id="main-content">
            <?php if($articles->isEmpty()): ?>
                <p class="notfound">No s'han trobat resultats</p>
            <?php else: ?>
                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="articles" tabindex="0">
                        <h2 tabindex="0"><?php echo e($article->nom); ?></h2>
                        <p tabindex="0"><?php echo e($article->descripcio); ?></p>
                        <p tabindex="0"><b>Autor:</b> <?php echo e($article->autor); ?></p>
                        <div class="gestio">
                            <a href="<?php echo e(route('articles.qr', ['nom' => $article->nom, 'descripcio' => $article->descripcio])); ?>">Clonar amb QR</a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
        
        <?php echo e($articles->appends(['buscar' => request('buscar'), 'articlesPerPagina' => request('articlesPerPagina'), 'ordreArticles' => request('ordreArticles')])->links()); ?>

        
        <form action="<?php echo e(route('home')); ?>">
            <input class="botons" type="submit" value="Tornar">
        </form>
    </div>
</body>
</html><?php /**PATH C:\laragon\www\migracioPractica\resources\views\index.blade.php ENDPATH**/ ?>
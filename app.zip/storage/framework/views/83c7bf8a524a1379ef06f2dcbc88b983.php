<!-- filepath: c:\laragon\www\migracioPractica\resources\views\inserirArticles.blade.php -->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/estilsForms.css')); ?>"> <!-- Estils css -->
    <title>Inserir Articles</title>
</head>
<body>
    <div>
        <h1>INSERTAR ARTICLES</h1>

    
        

        <div class="container">
            <form class="formUsuari" method="POST" action="<?php echo e(route('articles.store')); ?>">
                <?php echo csrf_field(); ?> 

                <label for="nom">Nom:</label>
                <input class="input-field" type="text" id="nom" name="nom" value="<?php echo e(old('nom')); ?>" required> <!-- Input pel nom -->
                <?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <label for="descripcio">Descripció:</label>
                <textarea id="descripcio" name="descripcio" rows="4" required><?php echo e(old('descripcio')); ?></textarea> <!-- Textarea pel missatge -->
                <?php $__errorArgs = ['descripcio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <?php if(session('success')): ?>
                    <div class="success-message">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                <input class="botons" type="submit" value="Crear Article">
            </form>

            <form action="<?php echo e(route('dashboard')); ?>">
                <input class="botons" type="submit" value="Tornar"> <!-- Botó per tornar a la pàgina principal -->
            </form>
        </div>
    </div>
</body>
</html><?php /**PATH C:\laragon\www\migracioPractica\resources\views\inserirArticles.blade.php ENDPATH**/ ?>